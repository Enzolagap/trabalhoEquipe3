<?php
    define("HOST","localhost");
    define("USUARIO","root");
    define("SENHA","");
    define("BANCO","cadastro");
?>